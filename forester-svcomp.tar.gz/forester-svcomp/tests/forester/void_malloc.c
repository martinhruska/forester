
#include <stdlib.h>

int main()
{
	void* v = malloc(1);
}
