/*
 * Check that main() returns zero by default
 */

int main()
{ }
