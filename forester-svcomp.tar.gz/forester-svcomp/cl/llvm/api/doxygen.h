// This file contains no code inside

/**
 * @file doxygen.h
 * @brief Doxygen documentation (common part)
 */
 
/**
 * @mainpage
 * @note See the
 * <A HREF="http://www.fit.vutbr.cz/research/groups/verifit/tools/code-listener/"><B>project page</B></A>
 * for details about the <B>Code Listener</B> project, new releases, etc.
 *
 * @remark
 *
 * Author: <B>Veronika Sokova</B>  xsokov00@stud.fit.vutbr.cz
 *
 */
