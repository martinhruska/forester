/* somewhere after gcc-4.5, include <gcc/hard-reg-set.h> somehow vanished */
#ifndef HARD_REG_SET
#   define HARD_REG_SET unsigned
#endif
