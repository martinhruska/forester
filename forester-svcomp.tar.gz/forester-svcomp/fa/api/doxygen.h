// This file contains no code inside

/**
 * @file doxygen.h
 * @brief Doxygen documentation (common part)
 */

/**
 * @mainpage
 * @note See the
 * <A HREF="http://www.fit.vutbr.cz/research/groups/verifit/tools/forester/"><B>project page</B></A>
 * for details about the <B>Forester</B> project, new releases, etc.
 * @version @include version.h
 *
 * @remark
 *
 * @todo
 */
